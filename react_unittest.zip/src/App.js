import React from 'react';
import Pages from './components';

function App() {
  return (
    <div>
      <Pages></Pages>
    </div>
  );
}

export default App;
