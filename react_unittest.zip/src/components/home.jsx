import React from "react";
import { Link } from 'react-router-dom';

const Home = () => {
    return (
        <div className="body">
            <div className="widget-header">
                <h3>Home Page</h3>
            </div>
            <div className="widget-body">
                <div className="row">
                    <ul>
                        <li>
                            <Link to="/list">List Page</Link>
                        </li>
                        <li>
                            <Link to="/todo">Todo Page</Link>
                        </li>
                        <li>
                            <Link to="/button">button test</Link>
                        </li>
                        <li>
                            <Link to="/search">search test</Link>
                        </li>

                    </ul>
                </div>
            </div>
        </div>
    )
}
export default Home;