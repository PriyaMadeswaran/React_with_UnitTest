import React, { useState } from "react";

const Button = () => {
    const [getName, setName] = useState("Click me");

    const handleClick = () => {
        if (getName === "Click me") {
            setName("You clicked me");
        }
        else {
            setName("Click me");
        }
    }
    return (
        <div className="body">

            <div className="row">
                <div className="col-md-4">
                    <button type="button" title="clickButton" onClick={handleClick}>{getName}</button>
                </div>
            </div>
        </div>
    )
}
export default Button;