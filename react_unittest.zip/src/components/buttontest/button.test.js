import { fireEvent, render } from "@testing-library/react";
import Button from "./button";

it("checkButton", () => {
    const { queryByTitle } = render(<Button />)
    const btn = queryByTitle("clickButton")
    expect(btn).toBeTruthy()
})

describe("click", () => {
    it("onClick", () => {
        const { queryByTitle } = render(<Button />)
        const btn = queryByTitle("clickButton")
        expect(btn.innerHTML).toBe("Click me")
        fireEvent.click(btn)
        expect(btn.innerHTML).toBe("You clicked me")
    })
})