import { fireEvent, render } from "@testing-library/react";
import Search from "./search";

it("checkSearch", () => {
    const { queryByTitle } = render(<Search />)
    const btn = queryByTitle("search")
    expect(btn).toBeTruthy()
})

describe("click", () => {
    it("onChange", () => {
        const { queryByTitle } = render(<Search />)
        const input = queryByTitle("search")
        fireEvent.change(input, { target: { value: "Unit Test" } })
        expect(input.value).toBe("Unit Test")
    })
})