import React, { useState } from "react";

const Button = () => {
    const [getText, setText] = useState('');

    const handleChange = (e) => {
        setText(e.target.value);
    }

    return (
        <div className="body">

            <div className="row">
                <div className="col-md-4">
                    <input className="form-control" title="search" value={getText} onChange={(event) => handleChange(event)} />
                </div>
            </div>
        </div>
    )
}
export default Button;