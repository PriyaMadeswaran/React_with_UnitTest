import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link } from 'react-router-dom';

const TodoList = () => {
    const [getList, setList] = useState([]);
    const [getText, setText] = useState('');
    const [getSelectedIndex, setSelectedIndex] = useState('');

    const value = [...getList];

    const saveText = () => {
        if (getText !== '') {
            if (getSelectedIndex === '') {
                value.push({
                    text: getText
                });
            }
            else {
                value[getSelectedIndex].text = getText;
            }
            setList(value);
            setText('');
            setSelectedIndex('');
        }
        else {
            alert("Please enter the name.");
        }
    }

    const handleChange = (event) => {
        setText(event.target.value);
    }
    const editText = (index) => {
        let selectedValue = value[index].text;
        setSelectedIndex(index);
        setText(selectedValue);
    }
    const deleteText = (index) => {
        value.splice(index, 1);
        setList(value);
    }

    return (
        <>
            <div className="body">
                <div className="row">
                    <div className="col-md-12">
                        <div className="widget-header heading_box_style">
                            <h3>Name List</h3>
                        </div>
                        <div className="widget-body">
                            <div className="row">
                                <div className="">
                                    <Link type="button" className="btn btn-primary floatRight" to="/" > Back</Link>
                                </div>
                            </div>
                            <div id="reg-form">
                                <form>
                                    <div className="row">
                                        <div className="col-md-3">

                                            <div className="form-group">
                                                <label>Enter Name</label>
                                                <input
                                                    className="form-control"
                                                    value={getText}
                                                    onChange={event => handleChange(event)}
                                                    maxLength="50"
                                                />
                                            </div>
                                        </div>

                                        <div className="col-md-3">
                                            <div className="form-group marginTop">
                                                <button className="btn btn-success" type="button" onClick={saveText}>Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                    {getList.length > 0 ?
                                        <div className="row">
                                            <div className="col-md-6">
                                                <table className="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>name</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {getList.map((item, index) =>
                                                        (
                                                            <tr>
                                                                <td>
                                                                    {
                                                                        item.text
                                                                    }
                                                                </td>
                                                                <td>
                                                                    <button className="btn btn-primary" type="button" onClick={() => editText(index)}>Edit</button>
                                                                    &nbsp;
                                                                    <button className="btn btn-danger" type="button" onClick={() => deleteText(index)}>Delete</button>
                                                                </td>
                                                            </tr>
                                                        ))
                                                        }
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        : ''}
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
};

export default TodoList;