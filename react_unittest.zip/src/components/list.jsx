import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { retrieveList } from "../actions/home";
import { Link } from 'react-router-dom';

const List = () => {
    const dispatch = useDispatch();
    const reducerState = useSelector((state) => state);
    const users = reducerState.home.userList;

    useEffect(() => {
        dispatch(retrieveList());
    }, [dispatch]);

    return (
        <div className="body">
            <div className="row">
                <div className="col-md-12">
                    <div className="widget-header heading_box_style">
                        <h3>Name List</h3>
                    </div>
                    <div className="widget-body">
                        <div className="row">
                            <div className="">
                                <Link type="button" className="btn btn-primary floatRight" to="/" > Back</Link>
                            </div>
                        </div>
                        <div className="row">
                            <ul>
                                {users.map(user => (
                                    <li key={user.id}>
                                        <Link to={`user/${user.id}`}>{user.name}</Link>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default List;