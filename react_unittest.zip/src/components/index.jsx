import React from "react";
import { BrowserRouter, BrowserRouter as Router, Route } from "react-router-dom";
import home from "./home";
import todo from "./todo";
import list from "./list";
import user from "./user";
import button from "./buttontest/button";
import search from "./searchtest/search";

const Index = () => {
    return (
        <Router>
            <Route exact path="/" component={home}></Route>
            <Route path="/todo" component={todo}></Route>
            <Route path="/list" component={list}></Route>
            <Route path="/button" component={button}></Route>
            <Route path="/search" component={search}></Route>
            <Route path="/user/:id" component={user}></Route>
        </Router>
    )
}
export default Index;