export const multiply = (num1, num2) => {
    return num1 * num2;
}

export const lower = (text) => {
    return text.toLowerCase();
}