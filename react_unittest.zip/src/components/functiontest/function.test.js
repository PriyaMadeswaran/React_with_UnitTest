import { multiply, lower } from "./function";

test("checkmultiply", () => {
    expect(multiply(2, 2)).toBe(4);
    expect(multiply(2, -2)).toBe(-4);
})

test("checklower", () => {
    expect(lower("COOL")).toBe('cool');
})