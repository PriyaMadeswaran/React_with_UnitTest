import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { retrieveUser } from "../actions/home";
import { Link } from 'react-router-dom';

const User = (props) => {
    const UserId = props.match.params.id;

    const dispatch = useDispatch();
    const reducerState = useSelector((state) => state);
    const user = reducerState.home.user;

    useEffect(() => {
        dispatch(retrieveUser(UserId));
    }, [dispatch]);

    return (
        <div className="body">
            <div className="row">
                <div className="col-md-12">
                    <div className="widget-header heading_box_style">
                        <h2>User Details</h2>
                    </div>
                    <div className="widget-body">
                        <div className="row">
                            <div className="">
                                <Link type="button" className="btn btn-primary floatRight" to="/" > Back</Link>
                            </div>
                        </div>
                        <div className="row">
                            <h1>{user.name}</h1>
                            <div>
                                Email: {user.email}
                            </div>
                            <div>
                                Phone: {user.phone}
                            </div>
                            <div>
                                Website: {user.website}
                            </div>
                            <div>
                                Company: {user.company === undefined ? '' : user.company.name}
                            </div>
                            <div>
                                Address: {user.address === undefined ? '' : user.address.street}, {user.address === undefined ? '' : user.address.suite}, {user.address === undefined ? '' : user.address.city}, {user.address === undefined ? '' : user.address.zipcode}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default User;